[CmdletBinding()]
param()

$serviceName = "RegistryMonitorService"
$installDir = Join-Path $env:ProgramFiles "RegistryMonitor"

Write-Host "Stopping service..."
try {
    # Try the standard way first
    Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3
    
    # Check if service is still running
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service -and $service.Status -ne 'Stopped') {
        Write-Host "Service didn't stop normally, using stronger methods..."
        # Find process ID
        $processID = (Get-WmiObject Win32_Service -Filter "Name='$serviceName'").ProcessId
        if ($processID -gt 0) {
            # Kill process forcefully
            Stop-Process -Id $processID -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 2
        }
    }
    
    Write-Host "Removing service..."
    sc.exe delete $serviceName
    Start-Sleep -Seconds 2
}
catch {
    Write-Host "Error stopping service: $_" -ForegroundColor Red
}

Write-Host "Cleaning installation directory..."
try {
    # Try to remove files with retries
    $maxAttempts = 3
    $attempt = 1
    
    while ($attempt -le $maxAttempts) {
        try {
            # Find any running processes locking our files
            $processes = Get-Process | Where-Object { 
                $_.Modules | Where-Object { 
                    $_.FileName -like "$installDir*" 
                } 
            }
            
            # Kill any processes using our files
            if ($processes) {
                Write-Host "Terminating processes that may lock files..."
                $processes | ForEach-Object { 
                    try { $_.Kill(); $_.WaitForExit(2000) } catch { } 
                }
                Start-Sleep -Seconds 2
            }
            
            # Remove directory
            Remove-Item -Path $installDir -Recurse -Force -ErrorAction Stop
            break
        }
        catch {
            if ($attempt -lt $maxAttempts) {
                Write-Host "Attempt $attempt failed, retrying in 3 seconds..."
                Start-Sleep -Seconds 3
                $attempt++
            }
            else {
                Write-Warning "Could not completely remove files. Please restart your computer and try again."
                break
            }
        }
    }
}
catch {
    Write-Host "Error removing files: $_" -ForegroundColor Red
}

Write-Host "Uninstallation completed."